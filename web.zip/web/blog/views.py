from django.shortcuts import render
from django.views.generic import ListView, DetailView
from .models import Post, Category





class ListViews(ListView):
    model = Post
    queryset = Post.objects.filter(published="bup")
    template_name = 'blog/index.html'
    context_object_name = 'posts'




class DetailViews(DetailView):
    model = Post
    template_name = 'blog/detail.html'
    context_object_name = 'post'

