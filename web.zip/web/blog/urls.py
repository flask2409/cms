from django.urls import path
from .views import ListViews, DetailViews

urlpatterns = [
    path('', ListViews.as_view()),
    path('detail/<url>', DetailViews.as_view(, name='detail'))
]