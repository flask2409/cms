from django.db import models
from django.urls import reverse
from django.contrib.auth.models import User


PUBLISHED = (
    ("pub", "Опубликованно"),
    ("trash", "Черновик"),
)


class Category(models.Model):
    title = models.CharField(verbose_name="Заголовок", max_length=244, unique=True)
    url = models.SlugField(verbose_name="Адрес", max_length=224, unique=True)

    def get_absolute_url(self):
        return reverse('category', args=[str(self.url)])

    def __str__(self):
        return "Категория - {0}".format(self.title)

    class Meta:
        verbose_name = "Категория"
        verbose_name_plural = "Категории"





class Post(models.Model):
    title = models.CharField(verbose_name="Заголовок", max_length=244, unique=True)
    url = models.SlugField(verbose_name="Адрес", max_length=224, unique=True)
    images = models.ImageField(verbose_name="Изображение", upload_to='uploads/%Y/%m/%d/')
    content = models.TextField(verbose_name="Контент", max_length=2000)
    category = models.ManyToManyField(Category, verbose_name="Категория")
    author = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="Автор")
    date_pub = models.DateTimeField(auto_now=True, verbose_name="Дата публикации")
    published = models.CharField(verbose_name="Статус", max_length=6, choices=PUBLISHED)
    
    def get_absolute_url(self):
        return reverse('detail', args=[str(self.url)])

    def __str__(self):
        return "Пост - {0}".format(self.title)



    class Meta:
        verbose_name = "Пост"
        verbose_name_plural = "Посты"



