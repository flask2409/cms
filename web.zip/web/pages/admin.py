from django.contrib import admin
from .models import Page


class PagesAdmin(admin.ModelAdmin):
    list_display = ('title','url')
    search_fields = ['title']
    
    prepopulated_fields = {"url": ("title",)}

admin.site.register(Page, PagesAdmin)
