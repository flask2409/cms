from django.db import models

class Page(models.Model):
    title = models.CharField(verbose_name="Заголовок", max_length=244, unique=True)
    url = models.SlugField(verbose_name="Адрес", max_length=224, unique=True)
    description = models.CharField(verbose_name="Описание", blank=True)
    keywords = models.CharField(verbose_name="Ключевые слова", blank=True)
    content = models.TextField(verbose_name="Контент", max_length=2000)
    
    
    def get_absolute_url(self):
        return reverse('page', args=[str(self.url)])

    def __str__(self):
        return "Страница - {0}".format(self.title)



    class Meta:
        verbose_name = "Страница"
        verbose_name_plural = "Страницы"
